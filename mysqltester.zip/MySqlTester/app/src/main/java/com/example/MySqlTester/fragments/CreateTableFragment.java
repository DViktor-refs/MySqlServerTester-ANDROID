package com.example.MySqlTester.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.MySqlTester.R;

import java.util.HashSet;
import java.util.Set;

public class CreateTableFragment extends Fragment {

    View view;
    Button runButton;
    TextView status;
    Set<String> connectionLoginData;

    public CreateTableFragment() { }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.createtablelayout, container, false);

        runButton = view.findViewById(R.id.ct_btn_run);
        status = view.findViewById(R.id.ct_tv_status);

        SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
        connectionLoginData = sharedPref.getStringSet("connectionLoginData", connectionLoginData);

        if (connectionLoginData != null) {
            status.setText("Connected");
        }

        return view;
    }
}