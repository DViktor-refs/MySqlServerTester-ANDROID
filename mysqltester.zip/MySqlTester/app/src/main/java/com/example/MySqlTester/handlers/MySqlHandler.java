package com.example.MySqlTester.handlers;

import static com.example.MySqlTester.SQLConsts.*;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import com.example.MySqlTester.Pairs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class MySqlHandler {

    private static final String TAG = "MySqlHandler";
    private static final String MYSQL57DRIVER = "com.mysql.jdbc.Driver";

    private Statement statement = null;
    private Connection connection = null;
    private Activity activity;
    private String url;
    private String localhost = "jdbc:mysql://10.0.2.2:3306/";

    public MySqlHandler(Activity activity, String url) {
        this.activity = activity;
        this.url = url;
    }

    public Connection connect(String user, String password) {

        ActivityCompat.requestPermissions(activity , new String[] {Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        if (url != null) {
            try {
                Class.forName(MYSQL57DRIVER).newInstance();
                connection = DriverManager.getConnection(url, user, password);
                Toast.makeText(activity.getApplicationContext(), "Connection Successful", Toast.LENGTH_SHORT).show();
            }

            catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
                e.printStackTrace();
                Toast.makeText(activity.getApplicationContext(), "Connection Unsuccessful", Toast.LENGTH_SHORT).show();
            }
        }
        return connection;
    }

    public void closeConnection(Connection connection) {

        try {
            connection.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            Log.e(TAG, "Error in closeConnection() : "+"Connection error, message: "+throwables.getMessage());
        }
    }

    public String getData(String tableName, List<String> columnNames ) {

        String query;
        String result = "";

        if (connection != null) {
            try {
                statement = connection.createStatement();
                query = getDataQuery(tableName, columnNames);
                ResultSet resultSet = statement.executeQuery(query);
                result = getResultFromResultSet(resultSet, columnNames);

            } catch (SQLException throwables) {
                throwables.printStackTrace();
                Log.e(TAG, "Error in getData() : " + "SQL exception, message: " + throwables.getMessage());
            }
        } else {
            Log.e(TAG, "Error in getData() : Please connect to server first.");
        }
        return result;
    }

    public void insertData(String tableName, List<String> columnNames, List<String> values ) {

        if (connection != null) {
            try {

                statement = connection.createStatement();
                statement.executeUpdate(insertDataQuery(tableName, columnNames, values));
            }
            catch (Exception e)
            {
                Log.e(TAG, "Error in insertData() : "+"Error, message: "+e.getMessage());
            }

        } else {
            Log.e(TAG, "Error in insertData() : Please connect to server first.");
        }
    }

    private String insertDataQuery(String tableName, List<String> columnNames, List<String> values) {

        String query = "INSERT INTO " +  tableName + " (";
        for (int i = 0; i < columnNames.size(); i++) {
            if (i != columnNames.size()-1) {
                query += columnNames.get(i) + ", ";
            }
            if (i == columnNames.size()-1) {
                query += columnNames.get(i) + ") VALUES (";
            }
        }

        for (int i = 0; i < values.size(); i++) {
            if (i != values.size()-1) {
                if(values.get(i).matches("\\d+")) {
                    query += values.get(i) + ", ";
                }
                else {
                    query += "\"" + values.get(i) +"\"" +  ", ";
                }

            }
            if(i == values.size()-1) {
                if(values.get(i).matches("\\d+")) {
                    query += values.get(i) + ")";
                }
                else {
                    query += "\"" + values.get(i) +"\"" + ")";
                }

            }
        }
        return query;
    }

    public boolean isColumnExist(String tableName, String columnName) {
        boolean result = false;

        if (connection != null) {
            try {

                statement =connection.createStatement();
                ResultSet resultSet = statement.executeQuery("select * " + "from " + tableName);
                ResultSetMetaData rsmd = resultSet.getMetaData();
                int columnCount = rsmd.getColumnCount();

                for (int i = 1; i <= columnCount; i++ ) {
                    if (rsmd.getColumnLabel(i).equals(columnName)) {
                        result = true;
                    }
                }
            }
            catch (Exception e)
            {
                Log.e(TAG, "Error in insertData() : "+"Error, message: "+e.getMessage());
            }

        } else {
            Log.e(TAG, "Error in insertData() : Please connect to server first.");
        }

        return result;
    }

    public void createDatabase (String databaseName) {

        if (connection != null) {
            try {
                String query = "create database " + IFNOTEXISTS  + databaseName;
                Log.e(TAG, "createDatabase query = " + query);
                statement = connection.createStatement();
                statement.executeUpdate(query);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }

    public void createTable(String dataBaseName, String tableName, List<String> columnNames, List<String> dataTypes, List<Pairs> constraints) {

            try {
                Connection con = DriverManager.getConnection(localhost + dataBaseName, "root", "");
                String query = getCreateTableQuery(tableName, columnNames, dataTypes, constraints);
                Log.e(TAG, "createTable query = " + query);
                statement = con.createStatement();
                statement.executeUpdate(query);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

    }

    private String getCreateTableQuery(String tableName, List<String> columnNames, List<String> dataTypes, List<Pairs> constraints) {
        String query = "";
        if (columnNames.size() == dataTypes.size()) {
            query = CREATETABLE + IFNOTEXISTS + tableName + SPACE + LBRACKET + columnNames.get(0) + SPACE + dataTypes.get(0) + COMA;
            if (constraints != null &&  constraints.get(0).getValueBy(0).equals(PRIMARYKEY)) {
                query += SPACE + PRIMARYKEY + COMA;
            }
            if (columnNames.size() > 0) {
                for (int i = 1; i < columnNames.size(); i++) {
                    if (i != columnNames.size()-1) {
                        if (constraints != null && constraints.get(i).getValue().equals(PRIMARYKEY)) {
                            query += columnNames.get(i) + SPACE + dataTypes.get(i) + SPACE + PRIMARYKEY + COMA;
                        } else {
                            query += columnNames.get(i) + SPACE + dataTypes.get(i) + COMA;
                        }
                    }
                    else {
                        if (constraints != null && constraints.get(i).getValue().equals(PRIMARYKEY)) {
                            query += columnNames.get(i) + SPACE + dataTypes.get(i) + SPACE + PRIMARYKEY + RBRACKET;
                        } else {
                            query += columnNames.get(i) + SPACE + dataTypes.get(i) + RBRACKET;
                        }
                    }

                }
            }
        }
        return query;
    }

    public void dropTable(String tableName) {
        try {

            statement =connection.createStatement();
            statement.executeUpdate("drop table " + tableName);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
            Log.e(TAG, "Error in clearTable() : Table name error Error, " + throwables.getMessage());
        }
    }

    public List<String> getColumnNames(String tableName) {
        List<String> result = new ArrayList<>();
        try {

            statement =connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from " + tableName);
            ResultSetMetaData rsmd = resultSet.getMetaData();
            int columnCount = rsmd.getColumnCount();

            for (int i = 1; i <= columnCount; i++ ) {
                result.add(rsmd.getColumnLabel(i));
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    private String getResultFromResultSet(ResultSet resultSet, List<String> nameOfColumns) {

        String result = "";
        String currentId;

        while (true) {
            try {
                if (!resultSet.next()) break;
                for (int i = 0; i < nameOfColumns.size(); i++) {
                    currentId = nameOfColumns.get(i);
                    if (i != nameOfColumns.size()) {
                        result += currentId + " = " + resultSet.getString(""+currentId) + " | ";
                    }
                    else {
                        result += currentId + " = " + resultSet.getString(""+currentId);
                    }
                }
                result += "\n";

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return result;
    }

    private String getDataQuery(String tableName, List<String> columnNames) {

        String query = "";
        if(!columnNames.isEmpty() && tableName != null ) {
            query = SELECT;
            if (columnNames.contains("*")) {
                query = query + "* " + FROM  + tableName;
            }
            else {
                query = SELECT;

                for (int i = 0; i < columnNames.size(); i++) {
                    if (i == 0) {
                        query = query + columnNames.get(0) + COMA;
                    }
                    else if (i == columnNames.size()-1) {
                        query = query + columnNames.get(i) +  SPACE + FROM + tableName;
                    }
                    else {
                        query = query + columnNames.get(i) + ", ";
                    }
                }
            }
        }
        return query;
    }


}
