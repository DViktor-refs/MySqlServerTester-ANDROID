package com.example.MySqlTester;

import android.content.Context;

import com.example.MySqlTester.handlers.ConnectionHelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetData {

    Connection connect;
    String ConnectionResult = "";
    Boolean isSuccess = false;
    Context ctx;

    public GetData() {}

    public List<Map<String, String>> doInBackground() {

        List<Map<String, String>> data = null;
        data = new ArrayList<Map<String, String>>();
        try {
            ConnectionHelper conStr = new ConnectionHelper();
            connect = conStr.connection("mysql.nethely.hu", "3306",
                    "v", "flatlee", "viktor123");
            if (connect == null) {
                ConnectionResult = "Check Your Internet Access!";
            } else {

                String query = "select * from countries";
                Statement stmt = connect.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                while (rs.next()) {
                    Map<String, String> datanum = new HashMap<String, String>();
                    datanum.put("ID", rs.getString("CountryId"));
                    datanum.put("Country", rs.getString("CountryName"));
                    datanum.put("Capital", rs.getString("CapitalCity"));
                    data.add(datanum);
                }

                ConnectionResult = " successful";
                isSuccess = true;
                connect.close();
            }
        } catch (Exception ex) {
            isSuccess = false;
            ConnectionResult = ex.getMessage();
        }

        return data;
    }
}



