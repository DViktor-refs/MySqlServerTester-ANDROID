package com.example.MySqlTester.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.MySqlTester.handlers.ConnectionHelper;
import com.example.MySqlTester.R;

import java.sql.Connection;
import java.util.HashSet;
import java.util.Set;

public class HomeFragment extends Fragment {

    Button runButton;
    View view;
    EditText et_hostName;
    EditText et_port;
    EditText et_databasename;
    EditText et_user;
    EditText et_pass;
    TextView et_status;
    ConnectionHelper connectionHelper = new ConnectionHelper();
    Connection connection;

    public HomeFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.homelayout, container, false);

        runButton =view.findViewById(R.id.home_btn_run);
        et_hostName = view.findViewById(R.id.ct_et_hostname);
        et_port = view.findViewById(R.id.home_et_portname);
        et_databasename = view.findViewById(R.id.home_et_dbname);
        et_user = view.findViewById(R.id.home_et_username);
        et_pass = view.findViewById(R.id.home_et_password);
        et_status = view.findViewById(R.id.home_tv_status);

        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String host = et_hostName.getText().toString();
                String port = et_port.getText().toString();
                String databasename = et_databasename.getText().toString();
                String user = et_user.getText().toString();
                String pass = et_pass.getText().toString();

                connectionHelper.setStatusTextViev(et_status);
                connection = connectionHelper.connection(host, port, databasename, user, pass);

                if (connection != null) {
                    Set<String> connectionLoginData = new HashSet<>();
                    connectionLoginData.add(host);
                    connectionLoginData.add(port);
                    connectionLoginData.add(databasename);
                    connectionLoginData.add(user);
                    connectionLoginData.add(pass);

                    SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putStringSet("connectionLoginData", connectionLoginData);
                    editor.apply();
                }
            }
        });
        return view;
    }
}