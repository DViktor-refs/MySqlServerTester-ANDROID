package com.example.MySqlTester;

public class SQLConsts {

    //<editor-fold desc="SQL Constans">
    // Commands
    public static final String CREATEDATABASE = "create database ";
    public static final String CREATETABLE = "create table ";
    public static final String SELECT = "select ";
    public static final String UPDATE = "update ";
    public static final String INSERTINTO = "insert into ";
    public static final String ALTERDATABASE = "alter database ";
    public static final String ALTERTABLE = "alter table ";
    public static final String DROPTABLE = "drop table ";
    public static final String SHOW = "show ";
    public static final String ADD = "add ";

    // Extended
    public static final String COLUMNS = "columns ";
    public static final String FROM = "from ";
    public static final String WHERE = "where ";

    // Constraints
    public static final String NOTNULL = "not null ";
    public static final String PRIMARYKEY = "primary key ";
    public static final String IFNOTEXISTS = "if not exists ";
    public static final String IFEXISTS = "if exists ";


    // Types
    public static final String VARCHAR10 = "varchar(10)";
    public static final String VARCHAR20 = "varchar(20)";
    public static final String VARCHAR30 = "varchar(30)";
    public static final String VARCHAR40 = "varchar(40)";
    public static final String VARCHAR50 = "varchar(50)";
    public static final String VARCHAR100 = "varchar(100)";
    public static final String VARCHAR150 = "varchar(150)";
    public static final String VARCHAR200 = "varchar(200)";
    public static final String VARCHAR255 = "varchar(255)";
    public static final String INT = "int";

    // punctuation marks

    public static final String QUOTES = "\"";
    public static final String COMA = ", ";
    public static final String NEWLINE = "\\n";
    public static final String SPACE = " ";
    public static final String LBRACKET = "(";
    public static final String RBRACKET = ")";

    //</editor-fold>




}
