package com.example.MySqlTester.handlers;

import android.os.StrictMode;
import android.util.Log;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionHelper {

    private TextView status;

    public ConnectionHelper() {

    }

    public void setStatusTextViev(TextView status) {
        this.status = status;
    }

    public Connection connection(String hostName, String port, String dataBaseName, String userName, String password) {

//        hostName = "mysql.nethely.hu";
//        port = "3306";
//        dataBaseName = "flatlee";
//        userName = "flatlee";
//        password = "Viktor123";

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        java.sql.Connection connection = null;
        String connectionUrl;
        String message = "Connected.";

        try{
            //Class.forName("com.mysql.jdbc.Driver");
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            connectionUrl = "jdbc:mysql://" + hostName + "/" + dataBaseName;
            connection = DriverManager.getConnection(connectionUrl, userName, password);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            message = ("Error: Class not found.");

        } catch (SQLException throwables) {
            throwables.printStackTrace();
            message = ("Error: " + throwables.getMessage());
        }

        status.setText(message);

        return connection;
    }

}
