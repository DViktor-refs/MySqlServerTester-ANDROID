package com.example.MySqlTester;


import static com.example.MySqlTester.SQLConsts.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.MySqlTester.fragments.CreateTableFragment;
import com.example.MySqlTester.fragments.HomeFragment;
import com.example.MySqlTester.handlers.MySqlHandler;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    Set<String> connectionLoginData;
    String defaultURL = "jdbc:mysql://mysql.nethely.hu:3306/";
    String jdbcUrl = "jdbc:mysql://";
    String defaultURLnaked = "mysql.nethely.hu";
    String defaultPort = "3306";

    private static final String TAG = "Mainactivity";
    Pairs pairs = new Pairs();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.remove("connectionLoginData");

        Spinner spinner = findViewById(R.id.spinner);

        MySqlHandler handler = new MySqlHandler(MainActivity.this, defaultURL);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);

        pairs.addPair(0, "PRIMARYKEY");

        List<String> columnNames = new ArrayList<>();
        List<String> dataTypes = new ArrayList<>();

        columnNames.add("id");
        columnNames.add("age");
        columnNames.add("name");

        dataTypes.add(INT);
        dataTypes.add(INT);
        dataTypes.add(VARCHAR20);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.mainmenuspinneritems, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        spinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String s = parent.getItemAtPosition(position).toString();
                        Log.d("selected spinner item : ", s);
                        if (s.equals("Test server")) {
                            setGuiIfTestServerSelected();
                        }
                        else if (s.equals("Create Table")) {
                            Log.d(TAG, "onItemSelected: create table clicked");
                            setGuiIfCreateTableSelected();
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

    }

    @Override
    protected void onStop() {
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.remove("connectionLoginData");
        editor.apply();
        super.onStop();
    }

    private void setGuiIfTestServerSelected() {
        getSupportFragmentManager().beginTransaction().replace(R.id.Frame, new HomeFragment()).commit();
    }

    private void setGuiIfCreateTableSelected() {
        getSupportFragmentManager().beginTransaction().replace(R.id.Frame, new CreateTableFragment()).commit();
    }





}




/*
 statement =connection.createStatement();
                        ResultSet resultSet = statement.executeQuery("select * from test");
                        while (resultSet.next()) {
                            text += "  id: " + resultSet.getString(3) +
                                    "  name: " + resultSet.getString(1) +
                                    "  age: " + resultSet.getString(2) + "\n";

                        }
 */