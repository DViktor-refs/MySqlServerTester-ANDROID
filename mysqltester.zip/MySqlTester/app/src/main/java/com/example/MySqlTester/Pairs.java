package com.example.MySqlTester;

import java.util.ArrayList;
import java.util.List;

public class Pairs {
    private int key;
    private String value;
    private List<Pairs> pairsList = new ArrayList<>();

    public Pairs(int key, String value) {
        this.key = key;
        this.value = value;
    }

    public int getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public String getValueBy(int key) {
        return pairsList.get(key).getValue();
    }

    public Pairs() { }

    public void addPair(int index, String value) {
        pairsList.add(new Pairs(index, value));
    }

    public List<Pairs> getPairsList() {
        if (!pairsList.isEmpty()) {
            return pairsList;
        }
        else {
            return null;
        }
    }




}
